package com.example.capston_design_2020cbot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {

    private EditText editTextsend;
    private TextView Text1;
    private TextView Text2;
    private Button buttonsend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        init();

    }




    private void init() {
        editTextsend = findViewById(R.id.editText_send);
        Text1 = findViewById(R.id.chattext1);
        Text2 = findViewById(R.id.chattext2);
        buttonsend = findViewById(R.id.button_send);

        ButtonAction();

    }

    private void ButtonAction() {
        buttonsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    String editdata = editTextsend.getText().toString();
                    String Textdata = null;
                    long now = System.currentTimeMillis();
                    Date time = new Date(now);
                    SimpleDateFormat format1 = new SimpleDateFormat("yyyy", Locale.getDefault());
                    SimpleDateFormat format2 = new SimpleDateFormat("MMdd",Locale.getDefault());
                    SimpleDateFormat format3 = new SimpleDateFormat("MM",Locale.getDefault());

                    String Year = format1.format(time);
                    String Month = format2.format(time);
                    String time3 = format3.format(time);
                    String greenhorm;
                    int point = 0;





                switch (time3)
                {
                    case  "12":
                        time3 = "12";
                        greenhorm  = "겨울";break;

                    case  "01":time3 = "01";greenhorm  = "겨울";break;
                    case  "02":time3 = "02";greenhorm  = "겨울";break;

                    case  "03":time3 = "03";greenhorm  = "봄";break;
                    case  "04":time3 = "04";greenhorm  = "봄";break;
                    case  "05":time3 = "05";greenhorm  = "봄";break;

                    case  "06":time3 = "06";greenhorm  = "여름";break;
                    case  "07":time3 = "07";greenhorm  = "여름";break;
                    case  "08":time3 = "08";greenhorm  = "여름";break;

                    case  "09":time3 = "09";greenhorm  = "가을";break;
                    case  "10":time3 = "10";greenhorm  = "가을";break;
                    case  "11":time3 = "11";greenhorm  = "가을";break;

                    default:
                        throw new IllegalStateException("" + time3);
                }

                //시간주석문




        if ("시작".equals(editdata)) {
            Textdata = "검사를 시작하겠습니다.\n" +
                    "1. 올 해는 몇 년도 입니까? \n" +
                    "(숫자만 입력하여 주세요)\n";


        } else {
            Textdata = "검사를 원하시면 시작 을 입력해주세요";
        }


                if (Year.equals(editdata)) {

                    Textdata = "2. 오늘은 몇월 몇일 입니까?\n" +
                            "(숫자만 입력하여 주세요)";
                    point++;



                }

                if (Month.equals(editdata)) {

                    Textdata = "3.지금은 무슨 계절입니까?\n";

                    point++;
                }


                if (greenhorm.equals(editdata)) {

                    Textdata = "시범검사는 여기까지 입니다\n" +
                            "감사합니다";
                    point++;
                }






                if("점수".equals(editdata))
                {
                    Textdata = "현재 점수는"+point+"점 입니다";
                }

                Text1.setText(Textdata);
                Text2.setText(editdata);
                editTextsend.setText(null);
            }
        });
    }

    }
